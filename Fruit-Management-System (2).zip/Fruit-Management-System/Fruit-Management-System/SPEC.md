# Fruit Shop Management System - Specification

## 1. Project Overview

**Project Name:** Fruit Shop Management System  
**Type:** Desktop Application (Java Swing GUI)  
**Core Functionality:** A comprehensive fruit shop management system that handles inventory management, shopping cart operations, automatic bill generation with discounts, and persistent data storage.  
**Target Users:** Small fruit shop owners and staff

---

## 2. UI/UX Specification

### Layout Structure

**Main Window:**
- Size: 1000x700 pixels
- Resizable: Yes (minimum 900x600)
- Title: "Fruit Shop Management System"

**Layout Areas:**
- **Header (Top):** Application title and current date/time
- **Left Panel (250px):** Navigation and quick actions
- **Center Panel (Main):** Dynamic content area based on selected operation
- **Status Bar (Bottom):** Status messages and notifications

### Visual Design

**Color Palette:**
- Primary: #2E7D32 (Forest Green)
- Secondary: #81C784 (Light Green)
- Accent: #FF8F00 (Amber)
- Background: #F1F8E9 (Light Green Tint)
- Text Primary: #1B5E20 (Dark Green)
- Text Secondary: #4CAF50 (Medium Green)
- Error: #D32F2F (Red)
- Success: #388E3C (Green)
- Panel Background: #FFFFFF (White)
- Border: #A5D6A7 (Pale Green)

**Typography:**
- Font Family: Segoe UI (Windows native)
- Heading 1: 24px, Bold
- Heading 2: 18px, Bold
- Body: 14px, Regular
- Small: 12px, Regular
- Button Text: 14px, Medium

**Spacing System:**
- Base unit: 8px
- Small padding: 8px
- Medium padding: 16px
- Large padding: 24px
- Component gap: 12px

**Visual Effects:**
- Card shadows: 0 2px 4px rgba(0,0,0,0.1)
- Button hover: Darken by 10%
- Transitions: 200ms ease-in-out
- Rounded corners: 8px for cards, 4px for buttons

### Components

**Navigation Panel:**
- Dashboard button
- Inventory button
- New Sale button
- View Bills button
- Exit button

**Dashboard View:**
- Today's sales summary card
- Total items in stock card
- Low stock alerts card
- Recent transactions list

**Inventory View:**
- Table showing all fruits with columns: ID, Name, Price/kg, Quantity, Unit
- Add new fruit button
- Update quantity button
- Delete fruit button
- Search/filter field

**New Sale View:**
- Fruit selection list (checkboxes)
- Quantity input per selected fruit
- Cart table showing added items
- Remove item button
- Apply discount dropdown (None, 5%, 10%, 15%, 20%)
- Customer name input (optional)
- Generate Bill button
- Clear Cart button

**Bill View:**
- Bill history table: Bill No, Date, Customer, Total Amount
- View Details button
- Print button
- Export to file button

**Component States:**
- Default: Normal appearance
- Hover: Slightly darker background
- Active/Selected: Primary color background
- Disabled: 50% opacity, no interaction

---

## 3. Functionality Specification

### Core Features

**1. Inventory Management**
- Add new fruit items with name, price per kg, initial quantity
- Update fruit quantity (stock in/out)
- Delete fruit items from inventory
- View all fruits in tabular format
- Search fruits by name
- Automatic low stock alert (when quantity < 5 kg)

**2. Shopping Cart**
- Select fruits from inventory
- Specify quantity for each selected fruit
- View cart with item details
- Remove items from cart
- Clear entire cart
- Real-time total calculation

**3. Bill Generation**
- Automatic bill number generation (FS-YYYYMMDD-XXXX)
- Include: Date, Customer name (if provided)
- Item details: Name, Quantity, Rate, Amount
- Subtotal calculation
- Discount application (5%, 10%, 15%, 20%)
- Final total with discount
- Save bill to file

**4. Data Persistence**
- Store inventory data in "inventory.dat"
- Store bill records in "bills.dat"
- Auto-save on changes
- Load data on application start

**5. Exception Handling**
- Invalid quantity input (negative/zero)
- Insufficient stock (requested > available)
- Empty cart on bill generation
- File read/write errors
- Invalid discount selection

### User Interactions and Flows

**Flow 1: Add Fruit to Inventory**
1. Click "Inventory" in navigation
2. Click "Add New Fruit" button
3. Enter fruit name, price, quantity
4. Click "Save"
5. System validates and saves
6. Success message displayed

**Flow 2: Make a Sale**
1. Click "New Sale" in navigation
2. Select fruits from available list
3. Enter quantity for each
4. Click "Add to Cart"
5. Review cart items
6. Select discount (optional)
7. Enter customer name (optional)
8. Click "Generate Bill"
9. Bill is generated and saved
10. Inventory automatically updated

**Flow 3: View Past Bills**
1. Click "View Bills" in navigation
2. View list of all bills
3. Select a bill to view details
4. Option to print or export

### Edge Cases

- Attempting to add fruit with duplicate name
- Selling more than available stock
- Invalid price/quantity input
- Corrupted data file recovery
- Empty inventory scenario

---

## 4. Acceptance Criteria

### Success Conditions

1. ✅ Application launches without errors
2. ✅ Can add new fruits to inventory
3. ✅ Can update fruit quantities
4. ✅ Can delete fruits from inventory
5. ✅ Can add fruits to cart with quantities
6. ✅ Cart displays correct items and totals
7. ✅ Discounts apply correctly to bill
8. ✅ Bill generates with all required details
9. ✅ Bills are saved to file and persist
10. ✅ Inventory updates after each sale
11. ✅ Error messages display for invalid inputs
12. ✅ Low stock warning appears when applicable

### Visual Checkpoints

1. Main window displays with green theme
2. Navigation buttons are clearly visible
3. Tables are properly formatted and scrollable
4. Forms have proper validation feedback
5. Bill output is properly formatted
6. All buttons have hover effects