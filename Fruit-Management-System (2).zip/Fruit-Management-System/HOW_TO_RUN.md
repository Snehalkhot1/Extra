run command - cd "c:\Users\rautm\Downloads\Fruit-Management-System\Fruit-Management-System\FruitShop\bin" ; java com.fruitshop.ui.FruitShopGUI

# 🍎 Fruit Shop Management System - How to Run

## Overview
This is a Java Swing-based Fruit Shop Management System with the following features:
- **Login System** with username, password, and role selection
- **Fruit Management** (Add, Update, Delete fruits with character-only validation)
- **Shopping Cart** functionality
- **Bill Generation** with customer name validation
- **Inventory Management**

## Features Added/Updated

### 1. **Login Page with Validation**
   - Username must contain only letters and spaces
   - Password validation (non-empty)
   - Role selection: Saler or Buyer
   - Methods in `FruitShopService`:
     - `validateLogin(username, password, role)`
     - `getCurrentUser()`
     - `getCurrentRole()`
     - `logout()`

### 2. **Customer Name Validation**
   - Only letters and spaces allowed (no numbers or symbols)
   - Validation applied in `generateBill()` method
   - Error message: "Customer name must contain only letters and spaces..."

### 3. **Fruit Name Validation**
   - Only letters and spaces allowed (no numbers or symbols)
   - Applied in:
     - `addFruit()` method
     - `updateFruitDetails()` method
   - Error message: "Fruit name must contain only letters (a-z, A-Z)..."

---

## 📋 Directory Structure
```
Fruit-Management-System/
├── FruitShop/
│   ├── src/
│   │   └── com/fruitshop/
│   │       ├── data/
│   │       │   └── FileHandler.java
│   │       ├── exception/
│   │       │   ├── EmptyCartException.java
│   │       │   ├── InsufficientStockException.java
│   │       │   └── InvalidInputException.java
│   │       ├── model/
│   │       │   ├── Bill.java
│   │       │   ├── CartItem.java
│   │       │   └── Fruit.java
│   │       ├── service/
│   │       │   └── FruitShopService.java
│   │       └── ui/
│   │           └── FruitShopGUI.java
│   └── bin/          (compiled classes go here)
└── HOW_TO_RUN.md
```

---

## 🚀 How to Run the Project

### **Step 1: Open Command Prompt or PowerShell**

### **Step 2: Navigate to the FruitShop directory**
```powershell
cd "c:\Users\rautm\Downloads\Fruit-Management-System\Fruit-Management-System\FruitShop"
```

### **Step 3: Compile all Java files**
```powershell
javac -d bin src/com/fruitshop/exception/*.java src/com/fruitshop/model/*.java src/com/fruitshop/data/*.java src/com/fruitshop/service/*.java src/com/fruitshop/ui/*.java
```

**Explanation:**
- `javac` = Java compiler command
- `-d bin` = Output compiled classes to the `bin` directory
- `src/com/fruitshop/*/*.java` = Compile all Java files from all packages

### **Step 4: Run the application**
```powershell
cd bin
java com.fruitshop.ui.FruitShopGUI
```

**Alternative (One-line command):**
```powershell
cd "c:\Users\rautm\Downloads\Fruit-Management-System\Fruit-Management-System\FruitShop\bin" ; java com.fruitshop.ui.FruitShopGUI
```

---

## ⚡ Complete Single Command (Copy & Paste)

**For Windows PowerShell:**
```powershell
cd "c:\Users\rautm\Downloads\Fruit-Management-System\Fruit-Management-System\FruitShop" ; javac -d bin src/com/fruitshop/exception/*.java src/com/fruitshop/model/*.java src/com/fruitshop/data/*.java src/com/fruitshop/service/*.java src/com/fruitshop/ui/*.java ; cd bin ; java com.fruitshop.ui.FruitShopGUI
```

---

## 🔐 Login Information

### Test Credentials:
The system accepts any non-empty username and password combination.

**Example 1 - Saler (Admin):**
- Username: `John Smith`
- Password: `admin123`
- Role: `Saler`

**Example 2 - Buyer (Customer):**
- Username: `Jane Doe`
- Password: `user123`
- Role: `Buyer`

**Note:** 
- Username must contain only letters and spaces
- Password can contain any characters but cannot be empty
- Select appropriate role from dropdown

---

## 📝 Understanding the Code

### **FruitShopService Methods**

#### Login Validation
```java
// Validates login credentials
validateLogin(String username, String password, String role)
// Returns: boolean
// Throws: InvalidInputException if any field is empty or invalid
```

#### Fruit Management (Character-only validation)
```java
// Add fruit with validation
addFruit(String name, double price, double quantity)
// name: Only letters and spaces allowed
// price: Must be > 0
// quantity: Must be >= 0

// Update fruit details with validation
updateFruitDetails(String id, String newName, double newPrice, double newQuantity)
// newName: Only letters and spaces allowed
```

#### Bill Generation (Customer name validation)
```java
// Generate bill with customer name validation
generateBill(String customerName, double discountPercent)
// customerName: Only letters and spaces allowed
// discountPercent: Discount percentage (0-100)
```

---

## ✅ Validation Rules Summary

| Field | Rule | Error Message |
|-------|------|---------------|
| Username | Letters & spaces only, non-empty | "Username must contain only letters and spaces..." |
| Password | Non-empty | "Password cannot be empty." |
| Fruit Name | Letters & spaces only, non-empty | "Fruit name must contain only letters..." |
| Customer Name | Letters & spaces only, non-empty | "Customer name must contain only letters..." |
| Price | Must be > 0 | "Price must be greater than zero." |
| Quantity | Must be >= 0 | "Quantity cannot be negative." |

---

## 🐛 Troubleshooting

### Issue 1: "Could not find or load main class"
**Solution:** Make sure you're in the `bin` directory before running the application.

### Issue 2: Compilation errors
**Solution:** Ensure all Java files are in the correct package structure:
```
src/com/fruitshop/exception/  ✓
src/com/fruitshop/model/      ✓
src/com/fruitshop/data/       ✓
src/com/fruitshop/service/    ✓
src/com/fruitshop/ui/         ✓
```

### Issue 3: "Username/Customer name contains invalid characters"
**Solution:** Only use letters (a-z, A-Z) and spaces. No numbers, symbols, or special characters allowed.

### Issue 4: GUI window doesn't appear
**Solution:** The application may be running. Check if a window appeared or use Alt+Tab to see if it's behind other windows.

---

## 🎯 Application Features

### **Saler/Admin Role Can:**
- Add new fruits to inventory
- Update fruit details (name, price, quantity)
- Delete fruits from inventory
- View inventory
- View bill history

### **Buyer/Customer Role Can:**
- View available fruits
- Add items to cart
- Remove items from cart
- Generate bills/checkout
- View previous bills

---

## 📊 Example Workflow

1. **Start Application**
   ```powershell
   java com.fruitshop.ui.FruitShopGUI
   ```

2. **Login Dialog Appears**
   - Enter Username: `Admin User`
   - Enter Password: `password123`
   - Select Role: `Saler`
   - Click Login

3. **Main Dashboard Opens**
   - Navigate using left sidebar
   - Go to Inventory to add fruits
   - Go to New Sale to process customer orders

---

## 💾 Data Persistence

- Inventory data is saved to file automatically
- Bills are saved after generation
- Data persists between application sessions

---

## 📚 File Descriptions

| File | Purpose |
|------|---------|
| `FruitShopGUI.java` | GUI interface and user interactions |
| `FruitShopService.java` | Business logic and validations |
| `FileHandler.java` | File I/O operations |
| `Fruit.java` | Fruit model class |
| `CartItem.java` | Shopping cart item model |
| `Bill.java` | Bill/Receipt model |
| `InvalidInputException.java` | Custom exception for input validation |
| `EmptyCartException.java` | Exception for empty cart |
| `InsufficientStockException.java` | Exception for low stock |

---

## ✨ Additional Notes

- The application uses Swing for GUI (built-in Java library)
- All data is serialized and saved to local files
- Color scheme: Green theme for professional look
- Supports both Admin (Saler) and Customer (Buyer) modes

---

**Enjoy using the Fruit Shop Management System! 🍎🍌🍊**
