from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional, List
import json
import os
from dotenv import load_dotenv
import openai
from googletrans import Translator
import speech_recognition as sr
from gtts import gTTS
import io
import base64
from datetime import datetime

# Load environment variables
load_dotenv()

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CHAT_HISTORY_FILE = os.path.join(BASE_DIR, "chat_history.json")

app = FastAPI(title="Smart Agriculture AI Assistant", version="1.0.0")

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize OpenAI client (fallback to rule-based if API key not set)
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
if OPENAI_API_KEY:
    openai.api_key = OPENAI_API_KEY
    use_llm = True
else:
    use_llm = False
    print("⚠️  OpenAI API key not found. Using rule-based responses.")

# Initialize translator
translator = Translator()

# Initialize speech recognizer
recognizer = sr.Recognizer()


class Question(BaseModel):
    message: str
    language: Optional[str] = "en"  # en, hi, mr
    user_id: Optional[str] = None


class VoiceRequest(BaseModel):
    audio_base64: str
    language: Optional[str] = "en"


class LanguageRequest(BaseModel):
    text: str
    target_language: str  # en, hi, mr


# Agriculture knowledge base
AGRICULTURE_KNOWLEDGE = """
You are an expert agriculture assistant helping farmers in India. Provide practical, 
actionable advice about:
- Crop cultivation (rice, wheat, maize, cotton, sugarcane, mango, banana, tomato, etc.)
- Pest and disease management
- Soil health and fertilizers (NPK, organic farming)
- Irrigation and water management
- Weather and seasonal farming (Kharif, Rabi, Zaid seasons)
- Organic farming practices
- Crop rotation and intercropping
- Market prices and selling strategies

Always respond in a friendly, helpful manner. If asked in Hindi or Marathi, respond in the same language.
"""


def get_llm_response(user_message: str, language: str = "en") -> str:
    """Get response from OpenAI LLM with agriculture context."""
    if not use_llm:
        return get_rule_based_response(user_message)
    
    try:
        system_prompt = AGRICULTURE_KNOWLEDGE
        if language == "hi":
            system_prompt += "\n\nRespond in Hindi (Devanagari script)."
        elif language == "mr":
            system_prompt += "\n\nRespond in Marathi (Devanagari script)."
        
        response = openai.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_message}
            ],
            temperature=0.7,
            max_tokens=500
        )
        return response.choices[0].message.content
    except Exception as e:
        print(f"LLM Error: {e}")
        return get_rule_based_response(user_message)


def get_rule_based_response(msg: str) -> str:
    """Fallback rule-based response system."""
    msg_lower = msg.lower()
    
    # Plant Database
    plant_database = {
        "mango": "Mango plant requires warm climate (25-30°C), well-drained soil, and moderate watering. Plant spacing: 10-12 meters. Harvest: April-June.",
        "banana": "Banana plant grows well in tropical climate with high humidity and regular watering. Requires rich, well-drained soil. Harvest: 12-15 months.",
        "cotton": "Cotton requires warm temperature (21-30°C) and well-drained black soil. Needs 600-800mm rainfall. Harvest: October-December.",
        "sugarcane": "Sugarcane needs high sunlight, fertile soil and frequent irrigation. Best temperature: 26-32°C. Harvest: 10-12 months.",
        "maize": "Maize grows best in warm climate (18-27°C) with well-drained fertile soil. Requires 50-100cm rainfall. Harvest: 80-100 days.",
        "rice": "Rice requires standing water during early growth stage and nitrogen fertilizer. Best temperature: 20-35°C. Harvest: 100-150 days.",
        "wheat": "Wheat grows well in cool climate (15-20°C) and needs proper irrigation management. Requires well-drained loamy soil. Harvest: 100-120 days.",
        "tomato": "Tomato requires well-drained soil, sunlight (6-8 hours), and pest monitoring. Best temperature: 20-25°C. Harvest: 60-90 days.",
    }
    
    # Check for plant names
    for plant, info in plant_database.items():
        if plant in msg_lower:
            return info
    
    # General responses
    if any(word in msg_lower for word in ["hi", "hello", "hey", "namaste"]):
        return "Hello Farmer! 🌾 How can I assist you today? Ask me about crops, pests, soil, fertilizers, or weather!"
    elif "thank" in msg_lower:
        return "You're welcome! Happy Farming 🌱"
    elif "yellow" in msg_lower or "yellowing" in msg_lower:
        return "Yellow leaves may indicate nitrogen deficiency. Apply urea or organic compost. Check for overwatering or root rot."
    elif "pest" in msg_lower or "insect" in msg_lower:
        return "Use neem oil spray (5ml per liter) to control pests. Apply early morning or evening. For severe infestation, consult local agriculture officer."
    elif "soil" in msg_lower:
        return "Test soil for NPK (Nitrogen, Phosphorus, Potassium) and pH levels (ideal: 6.0-7.5) for better yield. Add organic matter like compost or farmyard manure."
    elif "water" in msg_lower or "irrigation" in msg_lower:
        return "Maintain proper irrigation schedule to avoid root rot. Most crops need 1-2 inches of water per week. Use drip irrigation for water efficiency."
    elif "rain" in msg_lower or "rainfall" in msg_lower:
        return "Ensure proper drainage during heavy rainfall. Avoid waterlogging. Cover crops with plastic sheets if needed during excessive rain."
    elif "season" in msg_lower:
        return "Kharif crops (monsoon): rice, cotton, maize, sugarcane. Rabi crops (winter): wheat, barley, mustard. Zaid crops (summer): vegetables, watermelon."
    elif "fertilizer" in msg_lower or "fertiliser" in msg_lower:
        return "Use balanced NPK fertilizer (19:19:19) or organic alternatives. Apply during planting and growth stages. Test soil first to determine needs."
    elif "weather" in msg_lower:
        return "Monitor weather forecasts regularly. Protect crops from extreme temperatures, heavy rain, or drought. Use shade nets or greenhouses if needed."
    else:
        return "I'm here to help with farming questions! Ask about specific crops, pests, soil, fertilizers, weather, or irrigation. Please provide more details about your concern."


def translate_text(text: str, target_lang: str) -> str:
    """Translate text to target language."""
    lang_map = {"en": "en", "hi": "hi", "mr": "mr"}
    if target_lang not in lang_map:
        return text
    
    try:
        result = translator.translate(text, dest=lang_map[target_lang])
        return result.text
    except Exception as e:
        print(f"Translation error: {e}")
        return text


def load_history():
    """Load chat history from JSON file."""
    if not os.path.exists(CHAT_HISTORY_FILE):
        return []
    try:
        with open(CHAT_HISTORY_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError):
        return []


def save_history(history):
    """Save chat history to JSON file."""
    with open(CHAT_HISTORY_FILE, "w", encoding="utf-8") as f:
        json.dump(history, f, indent=4, ensure_ascii=False)


@app.on_event("startup")
def ensure_history_file():
    """Create chat history file if it does not exist."""
    if not os.path.exists(CHAT_HISTORY_FILE):
        save_history([])


@app.get("/")
def home():
    return {
        "message": "Smart Agriculture AI Assistant is running!",
        "features": ["Text Chat", "Voice Input/Output", "Multi-language (EN/HI/MR)", "LLM-powered responses"],
        "status": "active"
    }


@app.post("/ask")
def ask_ai(question: Question):
    """Main chat endpoint with language support."""
    user_message = question.message
    language = question.language or "en"
    
    # Get AI response
    response_text = get_llm_response(user_message, language)
    
    # Translate response if needed (for rule-based fallback)
    if language != "en" and not use_llm:
        response_text = translate_text(response_text, language)
    
    # Save chat history
    chat_entry = {
        "question": user_message,
        "answer": response_text,
        "language": language,
        "timestamp": datetime.now().isoformat(),
        "user_id": question.user_id
    }
    
    history = load_history()
    history.append(chat_entry)
    save_history(history)
    
    return {"response": response_text, "language": language}


@app.post("/voice-to-text")
async def voice_to_text(request: VoiceRequest):
    """Convert voice audio to text."""
    try:
        # Decode base64 audio
        audio_data = base64.b64decode(request.audio_base64)
        audio_file = io.BytesIO(audio_data)
        
        # Use speech recognition
        with sr.AudioFile(audio_file) as source:
            audio = recognizer.record(source)
        
        # Recognize speech based on language
        lang_map = {"en": "en-US", "hi": "hi-IN", "mr": "mr-IN"}
        language_code = lang_map.get(request.language, "en-US")
        
        try:
            text = recognizer.recognize_google(audio, language=language_code)
            return {"text": text, "language": request.language}
        except sr.UnknownValueError:
            return {"error": "Could not understand audio", "text": ""}
        except sr.RequestError as e:
            return {"error": f"Speech recognition error: {e}", "text": ""}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Voice processing error: {str(e)}")


@app.post("/text-to-speech")
def text_to_speech(request: LanguageRequest):
    """Convert text to speech audio."""
    try:
        lang_map = {"en": "en", "hi": "hi", "mr": "mr"}
        language_code = lang_map.get(request.target_language, "en")
        
        tts = gTTS(text=request.text, lang=language_code, slow=False)
        audio_buffer = io.BytesIO()
        tts.write_to_fp(audio_buffer)
        audio_buffer.seek(0)
        
        audio_base64 = base64.b64encode(audio_buffer.read()).decode('utf-8')
        return {"audio_base64": audio_base64, "language": request.target_language}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"TTS error: {str(e)}")


@app.post("/translate")
def translate(request: LanguageRequest):
    """Translate text to target language."""
    translated = translate_text(request.text, request.target_language)
    return {"original": request.text, "translated": translated, "language": request.target_language}


@app.get("/history")
def get_history(user_id: Optional[str] = None, limit: int = 50):
    """Get chat history."""
    history = load_history()
    if user_id:
        history = [h for h in history if h.get("user_id") == user_id]
    return {"history": history[-limit:]}


@app.get("/health")
def health_check():
    """Health check endpoint."""
    return {
        "status": "healthy",
        "llm_enabled": use_llm,
        "timestamp": datetime.now().isoformat()
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=True)