'use client'

import { useState, useEffect, useRef } from 'react'
import axios from 'axios'
import { FaMicrophone, FaMicrophoneSlash, FaLanguage, FaPaperPlane, FaVolumeUp } from 'react-icons/fa'
import './chat.css'

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:8000'

interface Message {
  id: string
  text: string
  sender: 'user' | 'ai'
  timestamp: Date
}

export default function Home() {
  const [messages, setMessages] = useState<Message[]>([])
  const [inputText, setInputText] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [language, setLanguage] = useState<'en' | 'hi' | 'mr'>('en')
  const [isListening, setIsListening] = useState(false)
  const [isRecording, setIsRecording] = useState(false)
  const [mediaRecorder, setMediaRecorder] = useState<MediaRecorder | null>(null)
  const [audioChunks, setAudioChunks] = useState<Blob[]>([])
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const recognitionRef = useRef<any>(null)

  const languages = {
    en: { name: 'English', flag: '🇬🇧' },
    hi: { name: 'हिंदी', flag: '🇮🇳' },
    mr: { name: 'मराठी', flag: '🇮🇳' },
  }

  useEffect(() => {
    // Initialize welcome message
    setMessages([{
      id: '1',
      text: language === 'en' 
        ? 'Hello Farmer! 🌾 How can I assist you today? Ask me about crops, pests, soil, fertilizers, or weather!'
        : language === 'hi'
        ? 'नमस्ते किसान! 🌾 मैं आज आपकी कैसे मदद कर सकता हूं? फसलों, कीटों, मिट्टी, उर्वरकों या मौसम के बारे में पूछें!'
        : 'नमस्कार शेतकरी! 🌾 मी आज तुमची कशी मदत करू शकतो? पिके, कीटक, माती, खते किंवा हवामानाबद्दल विचारा!',
      sender: 'ai',
      timestamp: new Date()
    }])
  }, [])

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  const sendMessage = async (text: string) => {
    if (!text.trim() || isLoading) return

    const userMessage: Message = {
      id: Date.now().toString(),
      text: text,
      sender: 'user',
      timestamp: new Date()
    }

    setMessages(prev => [...prev, userMessage])
    setInputText('')
    setIsLoading(true)

    try {
      const response = await axios.post(`${API_URL}/ask`, {
        message: text,
        language: language,
        user_id: 'default_user'
      })

      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: response.data.response,
        sender: 'ai',
        timestamp: new Date()
      }

      setMessages(prev => [...prev, aiMessage])
      
      // Auto text-to-speech for AI response
      if ('speechSynthesis' in window) {
        speakText(response.data.response)
      }
    } catch (error) {
      console.error('Error sending message:', error)
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: 'Sorry, I encountered an error. Please try again.',
        sender: 'ai',
        timestamp: new Date()
      }
      setMessages(prev => [...prev, errorMessage])
    } finally {
      setIsLoading(false)
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    sendMessage(inputText)
  }

  const startVoiceRecognition = () => {
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
      alert('Speech recognition not supported in your browser. Please use Chrome or Edge.')
      return
    }

    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition
    const recognition = new SpeechRecognition()
    
    recognition.continuous = false
    recognition.interimResults = false
    
    const langMap: { [key: string]: string } = {
      en: 'en-US',
      hi: 'hi-IN',
      mr: 'mr-IN'
    }
    recognition.lang = langMap[language] || 'en-US'

    recognition.onstart = () => {
      setIsListening(true)
    }

    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript
      setInputText(transcript)
      setIsListening(false)
      recognition.stop()
      sendMessage(transcript)
    }

    recognition.onerror = (event: any) => {
      console.error('Speech recognition error:', event.error)
      setIsListening(false)
      alert('Speech recognition error. Please try again.')
    }

    recognition.onend = () => {
      setIsListening(false)
    }

    recognition.start()
    recognitionRef.current = recognition
  }

  const stopVoiceRecognition = () => {
    if (recognitionRef.current) {
      recognitionRef.current.stop()
      setIsListening(false)
    }
  }

  const speakText = (text: string) => {
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(text)
      const langMap: { [key: string]: string } = {
        en: 'en-US',
        hi: 'hi-IN',
        mr: 'mr-IN'
      }
      utterance.lang = langMap[language] || 'en-US'
      utterance.rate = 0.9
      utterance.pitch = 1
      window.speechSynthesis.speak(utterance)
    }
  }

  const handleLanguageChange = (newLang: 'en' | 'hi' | 'mr') => {
    setLanguage(newLang)
  }

  return (
    <div className="chat-container">
      <div className="chat-header">
        <h1>🌾 Smart Agriculture AI Assistant</h1>
        <div className="language-selector">
          {Object.entries(languages).map(([code, lang]) => (
            <button
              key={code}
              className={`lang-btn ${language === code ? 'active' : ''}`}
              onClick={() => handleLanguageChange(code as 'en' | 'hi' | 'mr')}
              title={lang.name}
            >
              {lang.flag} {lang.name}
            </button>
          ))}
        </div>
      </div>

      <div className="chat-messages">
        {messages.map((message) => (
          <div key={message.id} className={`message ${message.sender}`}>
            <div className="message-content">
              <p>{message.text}</p>
              {message.sender === 'ai' && (
                <button
                  className="speak-btn"
                  onClick={() => speakText(message.text)}
                  title="Listen to response"
                >
                  <FaVolumeUp />
                </button>
              )}
            </div>
            <span className="message-time">
              {message.timestamp.toLocaleTimeString()}
            </span>
          </div>
        ))}
        {isLoading && (
          <div className="message ai">
            <div className="message-content">
              <div className="typing-indicator">
                <span></span>
                <span></span>
                <span></span>
              </div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      <form onSubmit={handleSubmit} className="chat-input">
        <div className="input-container">
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder={
              language === 'en'
                ? 'Ask about crops, pests, soil, fertilizers...'
                : language === 'hi'
                ? 'फसलों, कीटों, मिट्टी, उर्वरकों के बारे में पूछें...'
                : 'पिके, कीटक, माती, खते याबद्दल विचारा...'
            }
            disabled={isLoading}
          />
          <button
            type="button"
            className={`voice-btn ${isListening ? 'listening' : ''}`}
            onClick={isListening ? stopVoiceRecognition : startVoiceRecognition}
            title="Voice input"
          >
            {isListening ? <FaMicrophoneSlash /> : <FaMicrophone />}
          </button>
          <button
            type="submit"
            className="send-btn"
            disabled={isLoading || !inputText.trim()}
          >
            <FaPaperPlane />
          </button>
        </div>
      </form>
    </div>
  )
}