let chart;

const amountInput = document.getElementById('amount');
const rateInput = document.getElementById('rate');
const timeInput = document.getElementById('time');
const resultDiv = document.getElementById('result');
const errorDiv = document.getElementById('error');
const calculateBtn = document.getElementById('calculateBtn');
const resetBtn = document.getElementById('resetBtn');
const historyList = document.getElementById('historyList');
const clearHistoryBtn = document.getElementById('clearHistoryBtn');

const HISTORY_KEY = 'loanEMIHistory';

function formatCurrency(value) {
    return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 2 }).format(value);
}

function showError(message) {
    errorDiv.textContent = message;
    errorDiv.style.display = 'block';
    resultDiv.innerHTML = '';
}

function clearError() {
    errorDiv.style.display = 'none';
    errorDiv.textContent = '';
}

function saveHistory(entry) {
    const history = JSON.parse(localStorage.getItem(HISTORY_KEY) || '[]');
    history.unshift(entry);
    if (history.length > 10) history.pop();
    localStorage.setItem(HISTORY_KEY, JSON.stringify(history));
    renderHistory();
}

function renderHistory() {
    const history = JSON.parse(localStorage.getItem(HISTORY_KEY) || '[]');
    historyList.innerHTML = '';

    if (history.length === 0) {
        const empty = document.createElement('li');
        empty.textContent = 'No history yet. Calculate EMI to save entries.';
        empty.style.color = '#64748b';
        empty.style.cursor = 'default';
        historyList.appendChild(empty);
        return;
    }

    history.forEach((entry, index) => {
        const item = document.createElement('li');
        item.innerHTML = `<strong>${entry.date}</strong> - ₹${entry.amount} | ${entry.rate}% | ${entry.years} year(s) → EMI ${entry.emi}`;
        item.title = 'Click to load this calculation';
        item.addEventListener('click', () => {
            amountInput.value = entry.amount;
            rateInput.value = entry.rate;
            timeInput.value = entry.years;
            calculateEMI(false);
        });
        historyList.appendChild(item);
    });
}

function clearHistory() {
    localStorage.removeItem(HISTORY_KEY);
    renderHistory();
}

function calculateEMI(shouldSaveHistory = true) {
    clearError();

    const P = Number(amountInput.value);
    const annualR = Number(rateInput.value);
    const years = Number(timeInput.value);

    if (!P || !annualR || !years) {
        showError('Please provide valid values for all fields (greater than 0).');
        if (chart) chart.destroy();
        return;
    }

    const R = annualR / 12 / 100;
    const N = years * 12;

    const emiValue = (P * R * Math.pow(1 + R, N)) / (Math.pow(1 + R, N) - 1);
    const EMI = Number(emiValue.toFixed(2));
    const totalPayment = Number((EMI * N).toFixed(2));
    const totalInterest = Number((totalPayment - P).toFixed(2));

    resultDiv.innerHTML =
        `<div>EMI: <strong>${formatCurrency(EMI)}</strong></div>` +
        `<div>Total Payment: <strong>${formatCurrency(totalPayment)}</strong></div>` +
        `<div>Total Interest: <strong>${formatCurrency(totalInterest)}</strong></div>`;

    drawChart(P, totalInterest);

    if (shouldSaveHistory) {
        saveHistory({
            date: new Date().toLocaleString(),
            amount: P,
            rate: annualR,
            years: years,
            emi: formatCurrency(EMI),
            total: formatCurrency(totalPayment),
            interest: formatCurrency(totalInterest)
        });
    }
}

function drawChart(principal, interest) {
    const ctx = document.getElementById('chart').getContext('2d');

    if (chart) {
        chart.destroy();
    }

    chart = new Chart(ctx, {
        type: 'pie',
        data: {
            labels: ['Principal', 'Interest'],
            datasets: [{
                data: [principal, interest],
                backgroundColor: ['#1d4ed8', '#dc2626'],
                borderColor: '#fff',
                borderWidth: 2,
            }],
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'bottom'
                }
            }
        },
    });
}

function autoCalculate() {
    if (amountInput.value && rateInput.value && timeInput.value) {
        calculateEMI(false);
    }
}

amountInput.addEventListener('input', autoCalculate);
rateInput.addEventListener('input', autoCalculate);
timeInput.addEventListener('input', autoCalculate);
calculateBtn.addEventListener('click', () => calculateEMI(true));
resetBtn.addEventListener('click', () => {
    amountInput.value = '';
    rateInput.value = '';
    timeInput.value = '';
    resultDiv.innerHTML = '';
    clearError();
    if (chart) chart.destroy();
});
clearHistoryBtn.addEventListener('click', clearHistory);

renderHistory();