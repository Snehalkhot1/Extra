let plants = [];
const BACKEND_URL = 'http://localhost:5000';

const plantListEl = document.getElementById('plantList');
const modelViewer = document.getElementById('modelViewer');
const viewerTitle = document.getElementById('viewerTitle');
const plantInfo = document.getElementById('plantInfo');
const qrContainer = document.getElementById('qrContainer');
const qrLabel = document.getElementById('qrLabel');
const viewARButton = document.getElementById('viewARButton');
const viewVRButton = document.getElementById('viewVRButton');

let selectedPlant = null;

// Fetch plants from backend - CALL THIS FIRST
async function loadPlantsFromBackend() {
    try {
        const response = await fetch($/api/plants);
        if (!response.ok) throw new Error('Failed to fetch plants');
        plants = await response.json();
        createPlantList();
        loadSelectedPlantFromUrl();
    } catch (error) {
        console.error('Error loading plants:', error);
        plantListEl.innerHTML = '<p style="color: red;">Error loading plants. Make sure backend is running on port 5000.</p>';
    }
}

function createPlantList() {
    plantListEl.innerHTML = '';
    plants.forEach((plant) => {
        const item = document.createElement('button');
        item.type = 'button';
        item.className = 'plant-item';
        item.setAttribute('data-plant-id', plant.id);
        item.innerHTML = 
      <div>
        <span class="plant-name"></span>
        <span class="plant-type"></span>
      </div>
      <span>QR</span>
    ;

        item.addEventListener('click', () => selectPlant(plant, item));
        plantListEl.appendChild(item);
    });
}

function selectPlant(plant, itemElement) {
    selectedPlant = plant;
    const currentlySelected = document.querySelector('.plant-item.selected');
    if (currentlySelected) {
        currentlySelected.classList.remove('selected');
    }
    itemElement.classList.add('selected');

    viewerTitle.textContent = plant.name;
    plantInfo.innerHTML = 
    <strong>Type:</strong> <br>
    <strong>Description:</strong> 
  ;

    modelViewer.src = plant.modelUrl;
    modelViewer.alt = ${plant.name} 3D model;

    const url = generatePlantUrl(plant);
    generateQrCode(url);
    qrLabel.textContent = Scan to open plant page: ;
}

function generatePlantUrl(plant) {
    const location = window.location.href.replace(/[#?].*$/,'');
    return ${location}?plant=;
}

function generateQrCode(url) {
    qrContainer.innerHTML = '';
    const canvas = document.createElement('canvas');
    QRCode.toCanvas(canvas, url, { width: 240, margin: 1 }, (error) => {
        if (error) {
            qrContainer.textContent = 'Unable to generate QR code.';
            console.error(error);
            return;
        }
        qrContainer.appendChild(canvas);
    });
}

function setupArVrButtons() {
    viewARButton.addEventListener('click', () => {
        if (!selectedPlant) return;
        modelViewer.enterAR();
    });

    viewVRButton.addEventListener('click', () => {
        if (!selectedPlant) return;
        modelViewer.enterVR();
    });
}

function loadSelectedPlantFromUrl() {
    const params = new URLSearchParams(window.location.search);
    const plantId = params.get('plant');
    if (!plantId) return;

    const plant = plants.find((entry) => entry.id === plantId);
    if (!plant) return;

    const itemButtons = Array.from(document.querySelectorAll('.plant-item'));
    const item = itemButtons[plants.indexOf(plant)];
    if (item) {
        selectPlant(plant, item);
    }
}

// Initialize the app
loadPlantsFromBackend();
setupArVrButtons();
