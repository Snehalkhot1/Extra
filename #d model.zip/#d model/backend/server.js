const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
require('dotenv').config();

const plantRoutes = require('./routes/plants');
const qrcodeRoutes = require('./routes/qrcode');

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Routes
app.use('/api/plants', plantRoutes);
app.use('/api/qrcode', qrcodeRoutes);

// Root endpoint
app.get('/', (req, res) => {
    res.json({ message: 'Plant 3D Viewer Backend', status: 'Running', endpoints: ['/api/plants', '/api/qrcode', '/api/health'] });
});

// Health check endpoint
app.get('/api/health', (req, res) => {
    res.json({ status: 'Backend is running', timestamp: new Date() });
});

// Error handling middleware
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({ error: 'Internal server error', message: err.message });
});

app.listen(PORT, () => {
    console.log(`Backend server running on http://localhost:${PORT}`);
});