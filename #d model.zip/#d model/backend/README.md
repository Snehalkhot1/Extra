# Plant 3D + AR/VR Viewer - Backend

Node.js and Express-based backend for managing plant data, generating QR codes, and serving API endpoints.

## Features

- **Plant Management API**: CRUD operations for plant data
- **QR Code Generation**: Dynamically generate QR codes for direct plant linking
- **CORS Support**: Allow requests from frontend applications
- **Data Persistence**: JSON-based data storage

## Installation

1. Navigate to the backend directory:
   ```bash
   cd backend
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

## Configuration

Create or update the `.env` file:
```
PORT=5000
NODE_ENV=development
FRONTEND_URL=http://localhost:8000
```

## Running the Server

**Development mode (with auto-reload):**
```bash
npm run dev
```

**Production mode:**
```bash
npm start
```

The server will run on `http://localhost:5000` by default.

## API Endpoints

### Plants Management

#### Get all plants
```
GET /api/plants
```
Response:
```json
[
  {
    "id": "fern001",
    "name": "Bird's Nest Fern",
    "type": "Indoor plant",
    "description": "A lush fern...",
    "modelUrl": "models/birds-nest-fern.glb",
    "care": "Water regularly...",
    "difficulty": "Medium",
    "wateringFrequency": "2-3 times per week",
    "lightRequirement": "Indirect light"
  }
]
```

#### Get a specific plant
```
GET /api/plants/:id
```

#### Add a new plant
```
POST /api/plants
Content-Type: application/json

{
  "id": "aloe004",
  "name": "Aloe Vera",
  "type": "Medicinal plant",
  "description": "A small aloe plant...",
  "modelUrl": "models/aloe-vera.glb",
  "care": "Minimal watering required",
  "difficulty": "Easy",
  "wateringFrequency": "Once per week",
  "lightRequirement": "Bright indirect light"
}
```

#### Update a plant
```
PUT /api/plants/:id
Content-Type: application/json

{
  "description": "Updated description",
  "care": "Updated care instructions"
}
```

#### Delete a plant
```
DELETE /api/plants/:id
```

### QR Code Generation

#### Generate QR code (as data URL)
```
POST /api/qrcode/generate
Content-Type: application/json

{
  "plantId": "fern001",
  "frontendUrl": "http://localhost:8000"
}
```
Response:
```json
{
  "message": "QR code generated successfully",
  "qrCode": "data:image/png;base64,...",
  "url": "http://localhost:8000?plant=fern001",
  "plantId": "fern001"
}
```

#### Generate QR code (as downloadable image)
```
GET /api/qrcode/generate/:plantId
```
Returns PNG image file for download

#### Health Check
```
GET /api/health
```

## Project Structure

```
backend/
├── server.js              # Main server file
├── package.json           # Dependencies and scripts
├── .env                   # Environment variables
├── data/
│   └── plants.json        # Plant data storage
└── routes/
    ├── plants.js          # Plant management endpoints
    └── qrcode.js          # QR code generation endpoints
```

## Database

Plants data is stored in `data/plants.json`. Each plant object includes:
- `id`: Unique identifier
- `name`: Plant name
- `type`: Plant category
- `description`: Detailed description
- `modelUrl`: Path to GLB model file
- `care`: Care instructions
- `difficulty`: Care difficulty level
- `wateringFrequency`: How often to water
- `lightRequirement`: Light conditions needed

## Frontend Integration

To connect the frontend to the backend, update `app.js` to fetch plants from the API:

```javascript
async function loadPlantsFromBackend() {
  const response = await fetch('http://localhost:5000/api/plants');
  const plants = await response.json();
  // Use the plants data...
}
```

## Error Handling

The API returns appropriate HTTP status codes:
- `200`: Success
- `201`: Created successfully
- `400`: Bad request (missing fields)
- `404`: Resource not found
- `500`: Server error

## Dependencies

- **express**: Web framework
- **cors**: Cross-origin resource sharing
- **qrcode**: QR code generation
- **body-parser**: Request body parsing
- **dotenv**: Environment variable management
- **nodemon** (dev): Auto-restart on file changes

## Future Enhancements

- Database integration (MongoDB, PostgreSQL)
- User authentication and authorization
- Image upload for plant thumbnails
- Plant care tips and articles
- User wishlists and favorites
- Plant health tracking
