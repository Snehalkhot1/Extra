const express = require('express');
const QRCode = require('qrcode');

const router = express.Router();

// Generate QR code for a plant
router.post('/generate', async(req, res) => {
    try {
        const { plantId, frontendUrl } = req.body;

        if (!plantId || !frontendUrl) {
            return res.status(400).json({ error: 'Missing plantId or frontendUrl' });
        }

        const qrUrl = `${frontendUrl}?plant=${plantId}`;

        // Generate QR code as data URL
        const qrCodeDataUrl = await QRCode.toDataURL(qrUrl, {
            errorCorrectionLevel: 'H',
            type: 'image/png',
            width: 300,
            margin: 1
        });

        res.json({
            message: 'QR code generated successfully',
            qrCode: qrCodeDataUrl,
            url: qrUrl,
            plantId
        });
    } catch (error) {
        res.status(500).json({ error: 'Failed to generate QR code', details: error.message });
    }
});

// Generate QR code as image file
router.get('/generate/:plantId', async(req, res) => {
    try {
        const { plantId } = req.params;
        const frontendUrl = process.env.FRONTEND_URL || 'http://localhost:8000';

        const qrUrl = `${frontendUrl}?plant=${plantId}`;

        // Generate QR code as PNG buffer
        const qrCodeBuffer = await QRCode.toBuffer(qrUrl, {
            errorCorrectionLevel: 'H',
            type: 'image/png',
            width: 300,
            margin: 1
        });

        res.setHeader('Content-Type', 'image/png');
        res.setHeader('Content-Disposition', `attachment; filename="qr-code-${plantId}.png"`);
        res.send(qrCodeBuffer);
    } catch (error) {
        res.status(500).json({ error: 'Failed to generate QR code', details: error.message });
    }
});

module.exports = router;