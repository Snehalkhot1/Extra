const express = require('express');
const fs = require('fs');
const path = require('path');

const router = express.Router();
const plantsFilePath = path.join(__dirname, '../data/plants.json');

// Helper function to read plants data
function readPlantsData() {
    const data = fs.readFileSync(plantsFilePath, 'utf-8');
    return JSON.parse(data);
}

// Helper function to write plants data
function writePlantsData(data) {
    fs.writeFileSync(plantsFilePath, JSON.stringify(data, null, 2));
}

// Get all plants
router.get('/', (req, res) => {
    try {
        const data = readPlantsData();
        res.json(data.plants);
    } catch (error) {
        res.status(500).json({ error: 'Failed to retrieve plants', details: error.message });
    }
});

// Get a single plant by ID
router.get('/:id', (req, res) => {
    try {
        const data = readPlantsData();
        const plant = data.plants.find(p => p.id === req.params.id);

        if (!plant) {
            return res.status(404).json({ error: 'Plant not found' });
        }

        res.json(plant);
    } catch (error) {
        res.status(500).json({ error: 'Failed to retrieve plant', details: error.message });
    }
});

// Add a new plant
router.post('/', (req, res) => {
    try {
        const { id, name, type, description, modelUrl, care, difficulty, wateringFrequency, lightRequirement } = req.body;

        if (!id || !name || !type || !description || !modelUrl) {
            return res.status(400).json({ error: 'Missing required fields' });
        }

        const data = readPlantsData();

        if (data.plants.find(p => p.id === id)) {
            return res.status(400).json({ error: 'Plant with this ID already exists' });
        }

        const newPlant = {
            id,
            name,
            type,
            description,
            modelUrl,
            care: care || '',
            difficulty: difficulty || 'Medium',
            wateringFrequency: wateringFrequency || 'Weekly',
            lightRequirement: lightRequirement || 'Indirect light'
        };

        data.plants.push(newPlant);
        writePlantsData(data);

        res.status(201).json({ message: 'Plant added successfully', plant: newPlant });
    } catch (error) {
        res.status(500).json({ error: 'Failed to add plant', details: error.message });
    }
});

// Update a plant
router.put('/:id', (req, res) => {
    try {
        const data = readPlantsData();
        const plantIndex = data.plants.findIndex(p => p.id === req.params.id);

        if (plantIndex === -1) {
            return res.status(404).json({ error: 'Plant not found' });
        }

        data.plants[plantIndex] = {...data.plants[plantIndex], ...req.body };
        writePlantsData(data);

        res.json({ message: 'Plant updated successfully', plant: data.plants[plantIndex] });
    } catch (error) {
        res.status(500).json({ error: 'Failed to update plant', details: error.message });
    }
});

// Delete a plant
router.delete('/:id', (req, res) => {
    try {
        const data = readPlantsData();
        const plantIndex = data.plants.findIndex(p => p.id === req.params.id);

        if (plantIndex === -1) {
            return res.status(404).json({ error: 'Plant not found' });
        }

        const deletedPlant = data.plants.splice(plantIndex, 1);
        writePlantsData(data);

        res.json({ message: 'Plant deleted successfully', plant: deletedPlant[0] });
    } catch (error) {
        res.status(500).json({ error: 'Failed to delete plant', details: error.message });
    }
});

module.exports = router;