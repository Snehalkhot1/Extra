# Plant 3D + AR/VR Viewer

A simple browser module that lets you:
- Select a plant from a list
- View its 3D model in a WebXR-enabled viewer
- Generate a QR code for each plant
- Open the plant page directly from the QR link

## Files
- `index.html` — main page with 3D/AR viewer
- `styles.css` — UI styling
- `app.js` — plant selection, QR code generation, and viewer control

## Usage
1. Place GLB models in `models/`.
2. Update `app.js` with your plant details and model file names.
3. Run a local server from the folder:
   - `python -m http.server 8000`
   - or use any local server extension.
4. Open `http://localhost:8000` in a browser.

## Notes
- `model-viewer` provides the AR/VR support.
- The QR codes point to the same page with `?plant=<id>`.
- Replace placeholder GLB paths with real plant assets to see models.

## Adding More Plants
In `app.js`, add objects to the `plants` array with:
- `id`
- `name`
- `type`
- `description`
- `modelUrl`

Example:
```js
{
  id: 'aloe004',
  name: 'Aloe Vera',
  type: 'Medicinal plant',
  description: 'A small aloe plant ideal for sunny windows.',
  modelUrl: 'models/aloe-vera.glb',
}
```
